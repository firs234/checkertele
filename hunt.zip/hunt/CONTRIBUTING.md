# Contributing

To contribute to this project simply fork it, make all improvements, commit changes (squashing is recommended for multiple commits) and submit a pull request. That's it!  

If you have an issue, please *always* upload MadelineProto logs from when the error occurred to hastebin or similar websites.

If you make breaking changes, make sure to increase the number returned by the getV function in MTProto.php.  

Bye :)
