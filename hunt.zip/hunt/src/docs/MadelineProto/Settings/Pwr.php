<?php

namespace danog\MadelineProto\Settings;

use danog\MadelineProto\SettingsAbstract;

/**
 * PWRTelegram settings.
 */
class Pwr extends SettingsAbstract
{
}
