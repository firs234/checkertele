<?php

namespace danog\MadelineProto;

class SettingsEmpty extends SettingsAbstract
{
    public function mergeArray(array $settings): void
    {
    }
}
